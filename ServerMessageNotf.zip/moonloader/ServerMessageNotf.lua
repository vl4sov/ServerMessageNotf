script_name('ServerMessageNotf')
script_author('vl4sov')

require("lib.moonloader")
sampev = require("lib.samp.events")
imgui = require('imgui')
key = require('vkeys')
inicfg = require('inicfg')
faicons = require('faIcons')
encoding = require('encoding')
encoding.default = 'CP1251' 
band = bit.band
u8 = encoding.UTF8

fa_glyph_ranges = imgui.ImGlyphRanges({ faicons.min_range, faicons.max_range })

cfg = {}

cfg['notf'] = inicfg.load({
    style = {
        style = true
    },
    notf = {
        admins = 0,
        players = 0,
        gov = 0,
        news = 0,
        family = 0,
        fraction = 0,
        sms = 0
    },
    settings = {
        volume = 100,
        notfmessage = true,
        notfadmin = true,
        notffamily = true,
        familyname = 'Family Name',
        notffraction = true,
        notfgov = true,
        notfplayers = true,
        notfsms = true,
        notfnews = true
    }
}, "..\\ServerMessageNotf\\config\\notf.ini")

mainPath = getWorkingDirectory()..'\\ServerMessageNotf\\notf'

local soundNames = {
    u8'�����������', u8'Iphone', u8'VK', u8'�����������', u8'�����', u8'facebook', u8'SOS', u8'���� ����'
}

local VowelLet = {'�', '�', '�', '�', '�', '�', '�', '�', '�', '�'}

menu = imgui.ImBool(false)

function msg(text)
    sampAddChatMessage('ServerMessageNotf �{FFFFFF} '..text, 0xB2AAE6)
end

function log(text, tag, color)
	local colors = {
		['prime'] = string.format('{%x}', color and color or 0xFFFFD645),
		['white'] = string.format('{%x}', 0xFFFFFFFF)
	}
	local textOut = text and tostring(text) or 'Hello World!'
	local textOut = string.gsub(textOut, '{p}', colors['prime'])
	local textOut = string.gsub(textOut, '{w}', colors['white'])
	local tagOut = tag and string.format(' >> %s:', tag) or ':'
	local output = string.format('%s[ServerMessageNotf]%s{FFFFFF} %s', colors['prime'], tagOut, textOut)
	sampfuncsLog(output)
end

function saveIni(iniName)
	for name, _ in pairs(cfg) do
		if name == iniName then
			local saved = inicfg.save(cfg[name], string.format('..\\ServerMessageNotf\\config\\%s.ini', name))
            return saved
        end
	end
	log('������� ��������� �������������� ������������! ���������� � ������������', 'Configurator')
end

function main()
    repeat wait(0) until isSampAvailable()

    if sampRegisterChatCommand("notf", function () menu.v = not menu.v end) then msg('ServerMessageNotf is loaded') end

    if createDirectory(getWorkingDirectory()..'\\ServerMessageNotf\\config') then
        log('������� ����������� ������������', 'Configurator')
    end

    if createDirectory(getWorkingDirectory()..'\\ServerMessageNotf\\notf') then
        log('������� ����������� �����������', 'Notf')
    end

    for name, _ in pairs(cfg) do
        if not doesFileExist(getWorkingDirectory()..'\\ServerMessageNotf\\config\\' .. name .. '.ini') then
            if inicfg.save(cfg[name], string.format('..\\ServerMessageNotf\\config\\%s.ini', name)) then
                log('������� ����� ������������ - ' .. name .. '.ini', 'Configurator')
            else
                log('�� ������� ������� ������������ - ' .. name .. '.ini', 'Configurator')
            end
        end
    end

    addEventHandler("onWindowMessage", function (msg, wparam, lparam)
        if msg == 0x100 or msg == 0x101 then
            if wparam == key.VK_ESCAPE and (menu.v) and not isPauseMenuActive() and not sampIsDialogActive() and not isSampfuncsConsoleActive() and not sampIsChatInputActive() then
                consumeWindowMessage(true, false)
                if msg == 0x101 then
                    menu.v = false
                end
            end
        end
    end)

    while true do
        wait(0)

        imgui.Process = menu.v

    end
end

function dark_style()
    local style = imgui.GetStyle()
    local colors = style.Colors
    local clr = imgui.Col
    local ImVec4 = imgui.ImVec4

    style.WindowPadding = imgui.ImVec2(8, 8)
    style.WindowRounding = 10
    style.ChildWindowRounding = 5
    style.FramePadding = imgui.ImVec2(5, 3)
    style.FrameRounding = 3.0
    style.ItemSpacing = imgui.ImVec2(5, 4)
    style.ItemInnerSpacing = imgui.ImVec2(4, 4)
    style.IndentSpacing = 21
    style.ScrollbarSize = 10.0
    style.ScrollbarRounding = 13
    style.GrabMinSize = 8
    style.GrabRounding = 1
    style.WindowTitleAlign = imgui.ImVec2(0.5, 0.5)
    style.ButtonTextAlign = imgui.ImVec2(0.5, 0.5)

    colors[clr.Text] = ImVec4(0.80, 0.80, 0.83, 1.00)
    colors[clr.TextDisabled] = ImVec4(0.24, 0.23, 0.29, 1.00)
    colors[clr.WindowBg] = ImVec4(0.06, 0.05, 0.07, 1.00)
    colors[clr.ChildWindowBg] = ImVec4(0.06, 0.05, 0.07, 1.00)
    colors[clr.PopupBg] = ImVec4(0.07, 0.07, 0.09, 1.00)
    colors[clr.Border] = ImVec4(0.80, 0.80, 0.83, 0.88)
    colors[clr.BorderShadow] = ImVec4(0.92, 0.91, 0.88, 0.00)
    colors[clr.FrameBg] = ImVec4(0.10, 0.09, 0.12, 1.00)
    colors[clr.FrameBgHovered] = ImVec4(0.24, 0.23, 0.29, 1.00)
    colors[clr.FrameBgActive] = ImVec4(0.56, 0.56, 0.58, 1.00)
    colors[clr.TitleBg] = ImVec4(0.10, 0.09, 0.12, 1.00)
    colors[clr.TitleBgCollapsed] = ImVec4(1.00, 0.98, 0.95, 0.75)
    colors[clr.TitleBgActive] = ImVec4(0.07, 0.07, 0.09, 1.00)
    colors[clr.MenuBarBg] = ImVec4(0.10, 0.09, 0.12, 1.00)
    colors[clr.ScrollbarBg] = ImVec4(0.10, 0.09, 0.12, 1.00)
    colors[clr.ScrollbarGrab] = ImVec4(0.80, 0.80, 0.83, 0.31)
    colors[clr.ScrollbarGrabHovered] = ImVec4(0.56, 0.56, 0.58, 1.00)
    colors[clr.ScrollbarGrabActive] = ImVec4(0.06, 0.05, 0.07, 1.00)
    colors[clr.ComboBg] = ImVec4(0.19, 0.18, 0.21, 1.00)
    colors[clr.CheckMark] = ImVec4(0.80, 0.80, 0.83, 0.31)
    colors[clr.SliderGrab] = ImVec4(0.80, 0.80, 0.83, 0.31)
    colors[clr.SliderGrabActive] = ImVec4(0.06, 0.05, 0.07, 1.00)
    colors[clr.Button] = ImVec4(0.10, 0.09, 0.12, 1.00)
    colors[clr.ButtonHovered] = ImVec4(0.24, 0.23, 0.29, 1.00)
    colors[clr.ButtonActive] = ImVec4(0.56, 0.56, 0.58, 1.00)
    colors[clr.Header] = ImVec4(0.10, 0.09, 0.12, 1.00)
    colors[clr.HeaderHovered] = ImVec4(0.56, 0.56, 0.58, 1.00)
    colors[clr.HeaderActive] = ImVec4(0.06, 0.05, 0.07, 1.00)
    colors[clr.ResizeGrip] = ImVec4(0.00, 0.00, 0.00, 0.00)
    colors[clr.ResizeGripHovered] = ImVec4(0.56, 0.56, 0.58, 1.00)
    colors[clr.ResizeGripActive] = ImVec4(0.06, 0.05, 0.07, 1.00)
    colors[clr.CloseButton] = ImVec4(0.40, 0.39, 0.38, 0.16)
    colors[clr.CloseButtonHovered] = ImVec4(0.40, 0.39, 0.38, 0.39)
    colors[clr.CloseButtonActive] = ImVec4(0.40, 0.39, 0.38, 1.00)
    colors[clr.PlotLines] = ImVec4(0.40, 0.39, 0.38, 0.63)
    colors[clr.PlotLinesHovered] = ImVec4(0.25, 1.00, 0.00, 1.00)
    colors[clr.PlotHistogram] = ImVec4(0.40, 0.39, 0.38, 0.63)
    colors[clr.PlotHistogramHovered] = ImVec4(0.25, 1.00, 0.00, 1.00)
    colors[clr.TextSelectedBg] = ImVec4(0.25, 1.00, 0.00, 0.43)
    colors[clr.ModalWindowDarkening] = ImVec4(1.00, 0.98, 0.95, 0.73)
end

function light_style()
    local style = imgui.GetStyle()
    local colors = style.Colors
    local clr = imgui.Col
    local ImVec4 = imgui.ImVec4

    style.WindowPadding = imgui.ImVec2(8, 8)
    style.WindowRounding = 10
    style.ChildWindowRounding = 5
    style.FramePadding = imgui.ImVec2(5, 3)
    style.FrameRounding = 3.0
    style.ItemSpacing = imgui.ImVec2(5, 4)
    style.ItemInnerSpacing = imgui.ImVec2(4, 4)
    style.IndentSpacing = 21
    style.ScrollbarSize = 10.0
    style.ScrollbarRounding = 13
    style.GrabMinSize = 8
    style.GrabRounding = 1
    style.WindowTitleAlign = imgui.ImVec2(0.5, 0.5)
    style.ButtonTextAlign = imgui.ImVec2(0.5, 0.5)

    colors[clr.Text] = ImVec4(0.00, 0.00, 0.00, 0.51)
    colors[clr.TextDisabled] = ImVec4(0.24, 0.24, 0.24, 1.00)
    colors[clr.WindowBg] = ImVec4(1.00, 1.00, 1.00, 1.00)
    colors[clr.ChildWindowBg] = ImVec4(1.00, 1.00, 1.00, 1.00)
    colors[clr.PopupBg] = ImVec4(0.92, 0.92, 0.92, 1.00)
    colors[clr.Border] = ImVec4(0.86, 0.86, 0.86, 1.00)
    colors[clr.BorderShadow] = ImVec4(0.00, 0.00, 0.00, 0.00)
    colors[clr.FrameBg] = ImVec4(0.88, 0.88, 0.88, 1.00)
    colors[clr.FrameBgHovered] = ImVec4(0.24, 0.23, 0.29, 1.00)
    colors[clr.FrameBgActive] = ImVec4(0.76, 0.76, 0.76, 1.00)
    colors[clr.TitleBg] = ImVec4(0.00, 0.45, 1.00, 0.82)
    colors[clr.TitleBgCollapsed] = ImVec4(0.00, 0.45, 1.00, 0.82)
    colors[clr.TitleBgActive] = ImVec4(0.00, 0.45, 1.00, 0.82)
    colors[clr.MenuBarBg] = ImVec4(0.00, 0.00, 0.00, 0.00)
    colors[clr.ScrollbarBg] = ImVec4(0.10, 0.09, 0.12, 1.00)
    colors[clr.ScrollbarGrab] = ImVec4(0.00, 0.35, 1.00, 0.78)
    colors[clr.ScrollbarGrabHovered] = ImVec4(0.56, 0.56, 0.58, 1.00)
    colors[clr.ScrollbarGrabActive] = ImVec4(0.00, 0.31, 1.00, 0.88)
    colors[clr.ComboBg] = ImVec4(0.92, 0.92, 0.92, 1.00)
    colors[clr.CheckMark] = ImVec4(0.80, 0.80, 0.83, 0.31)
    colors[clr.SliderGrab] = ImVec4(0.80, 0.80, 0.83, 0.31)
    colors[clr.SliderGrabActive] = ImVec4(0.06, 0.05, 0.07, 1.00)
    colors[clr.Button] = ImVec4(0.00, 0.49, 1.00, 0.59)
    colors[clr.ButtonHovered] = ImVec4(0.00, 0.49, 1.00, 0.78)
    colors[clr.ButtonActive] = ImVec4(0.00, 0.49, 1.00, 0.78)
    colors[clr.Header] = ImVec4(0.00, 0.49, 1.00, 0.78)
    colors[clr.HeaderHovered] = ImVec4(0.00, 0.49, 1.00, 0.78)
    colors[clr.HeaderActive] = ImVec4(0.00, 0.49, 1.00, 0.78)
    colors[clr.ResizeGrip] = ImVec4(0.00, 0.39, 1.00, 0.59)
    colors[clr.ResizeGripHovered] = ImVec4(0.00, 0.27, 1.00, 0.59)
    colors[clr.ResizeGripActive] = ImVec4(0.00, 0.25, 1.00, 0.63)
    colors[clr.CloseButton] = ImVec4(0.00, 0.35, 0.96, 0.71)
    colors[clr.CloseButtonHovered] = ImVec4(0.00, 0.31, 0.88, 0.69)
    colors[clr.CloseButtonActive] = ImVec4(0.00, 0.25, 0.88, 0.67)
    colors[clr.PlotLines] = ImVec4(0.00, 0.39, 1.00, 0.75)
    colors[clr.PlotLinesHovered] = ImVec4(0.00, 0.39, 1.00, 0.75)
    colors[clr.PlotHistogram] = ImVec4(0.00, 0.39, 1.00, 0.75)
    colors[clr.PlotHistogramHovered] = ImVec4(0.00, 0.35, 0.92, 0.78)
    colors[clr.TextSelectedBg] = ImVec4(0.00, 0.47, 1.00, 0.59)
    colors[clr.ModalWindowDarkening] = ImVec4(0.20, 0.20, 0.20, 0.35)
end

function imgui.BeforeDrawFrame()
    if fa_font == nil then
        local font_config = imgui.ImFontConfig()
        font_config.MergeMode = true
    
        fa_font = imgui.GetIO().Fonts:AddFontFromFileTTF('moonloader/resource/fonts/fontawesome-webfont.ttf', 14.0, font_config, fa_glyph_ranges)
      end
    if fontsize == nil then
        fontsize = imgui.GetIO().Fonts:AddFontFromFileTTF(getFolderPath(0x14) .. '\\trebucbd.ttf', 30.0, nil, imgui.GetIO().Fonts:GetGlyphRangesCyrillic()) -- ������ 30 ����� ������ ������
    end
    if fontsizee == nil then
        fontsizee = imgui.GetIO().Fonts:AddFontFromFileTTF(getFolderPath(0x14) .. '\\trebucbd.ttf', 17.0, nil, imgui.GetIO().Fonts:GetGlyphRangesCyrillic()) -- ������ 30 ����� ������ ������
    end
end

function imgui.OnDrawFrame()
    if cfg['notf'].style.style then
        dark_style()
    else
        light_style()
    end

    volume = imgui.ImInt(cfg['notf'].settings.volume)
    soundadmins = imgui.ImInt(cfg['notf'].notf.admins)
    soundplayers = imgui.ImInt(cfg['notf'].notf.players)
    soundgov = imgui.ImInt(cfg['notf'].notf.gov)
    soundnews = imgui.ImInt(cfg['notf'].notf.news)
    soundfamily = imgui.ImInt(cfg['notf'].notf.family)
    soundfraction = imgui.ImInt(cfg['notf'].notf.fraction)
    soundsms = imgui.ImInt(cfg['notf'].notf.sms)
    notfmessage = imgui.ImBool(cfg['notf'].settings.notfmessage)
    notfadmin = imgui.ImBool(cfg['notf'].settings.notfadmin)
    notffamily = imgui.ImBool(cfg['notf'].settings.notffamily)
    notffraction = imgui.ImBool(cfg['notf'].settings.notffraction)
    notfgov = imgui.ImBool(cfg['notf'].settings.notfgov)
    notfnews = imgui.ImBool(cfg['notf'].settings.notfnews)
    notfplayers = imgui.ImBool(cfg['notf'].settings.notfplayers)
    notfsms = imgui.ImBool(cfg['notf'].settings.notfsms)
    familyname = imgui.ImBuffer(u8(cfg['notf'].settings.familyname), 256)

    if menu.v then
        imgui.ShowCursor = true
        local iScreenWidth, iScreenHeight = getScreenResolution()
        imgui.SetNextWindowPos(imgui.ImVec2(iScreenWidth / 2, iScreenHeight / 2), imgui.Cond.FirstUseEver, imgui.ImVec2(0.5, 0.5))
        imgui.SetNextWindowSize(imgui.ImVec2(512, 315), imgui.Cond.FirstUseEver)
        imgui.Begin(faicons.ICON_VOLUME_UP ..u8'  ServerMessageNotf', menu, imgui.WindowFlags.NoResize + imgui.WindowFlags.NoCollapse + imgui.WindowFlags.NoMove) 
        
            imgui.BeginChild('##leftmenu', imgui.ImVec2(250, 262), false)

                imgui.CenterTextColoredRGB('��������� �����������')

                if imgui.CustomSlider("��������� �����������", 0, 100, 200, volume) then
                    cfg['notf'].settings.volume = volume.v
                    saveIni('notf')
                end

                imgui.SetCursorPosX(15)
                if imgui.ToggleButton(u8'���������� ���������', notfmessage) then
                    cfg['notf'].settings.notfmessage = notfmessage.v
                    saveIni('notf')
                end


                imgui.Text('')

                imgui.CenterTextColoredRGB('����������� ��')

                imgui.Text('')
                
                imgui.SetCursorPosX(50)
                if imgui.ToggleButton(u8'�������������', notfadmin) then
                    cfg['notf'].settings.notfadmin = notfadmin.v
                    saveIni('notf')
                end

                imgui.SetCursorPosX(50)
                if imgui.ToggleButton(u8'�����', notffamily) then
                    cfg['notf'].settings.notffamily = notffamily.v
                    saveIni('notf')
                end
                    if cfg['notf'].settings.notffamily then
                        imgui.SameLine()
                        imgui.PushItemWidth(100)
                        if imgui.InputText(u8("##�������� ����"), familyname) then
                            cfg['notf'].settings.familyname = u8:decode(familyname.v)
                            saveIni('notf')
                        end
                        imgui.PopItemWidth()
                    end

                imgui.SetCursorPosX(50)
                if imgui.ToggleButton(u8'�������', notffraction) then
                    cfg['notf'].settings.notffraction = notffraction.v
                    saveIni('notf')
                end

                imgui.SetCursorPosX(50)
                if imgui.ToggleButton(u8'/gov', notfgov) then
                    cfg['notf'].settings.notfgov = notfgov.v
                    saveIni('notf')
                end

                imgui.SetCursorPosX(50)
                if imgui.ToggleButton(u8'��������', notfnews) then
                    cfg['notf'].settings.notfnews = notfnews.v
                    saveIni('notf')
                end

                imgui.SetCursorPosX(50)
                if imgui.ToggleButton(u8'�������', notfplayers) then
                    cfg['notf'].settings.notfplayers = notfplayers.v
                    saveIni('notf')
                end

                imgui.SetCursorPosX(50)
                if imgui.ToggleButton(u8'SMS', notfsms) then
                    cfg['notf'].settings.notfsms = notfsms.v
                    saveIni('notf')
                end

            imgui.EndChild()

            imgui.SameLine()

            imgui.BeginChild('##rightmenu', imgui.ImVec2(240, 265), false)

                imgui.CenterTextColoredRGB('��������� ������ �����������')

                imgui.SetCursorPosY(30)
                imgui.PushItemWidth(120)

                    if imgui.Combo(u8 '�������������', soundadmins, soundNames) then
                        msg(("�� ������� ����: {B2AAE6}%s"):format(u8:decode(soundNames[soundadmins.v + 1])))
                        cfg['notf'].notf.admins = soundadmins.v
                        saveIni('notf')
                        if cfg['notf'].notf.admins == 0 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/admin.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.admins == 1 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/iphone.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.admins == 2 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/vk.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.admins == 3 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/notification.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.admins == 4 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/icq.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.admins == 5 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/facebook.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.admins == 6 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/sos.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.admins == 7 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/mysound.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        end
                    end

                    if imgui.Combo(u8 '�����', soundfamily, soundNames) then
                        msg(("�� ������� ����: {B2AAE6}%s"):format(u8:decode(soundNames[soundfamily.v + 1])))
                        cfg['notf'].notf.family = soundfamily.v
                        saveIni('notf')
                        if cfg['notf'].notf.family == 0 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/family.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.family == 1 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/iphone.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.family == 2 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/vk.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.family == 3 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/notification.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.family == 4 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/icq.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.family == 5 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/facebook.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.family == 6 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/sos.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.family == 7 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/mysound.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        end
                    end

                    if imgui.Combo(u8 '�������', soundfraction, soundNames) then
                        msg(("�� ������� ����: {B2AAE6}%s"):format(u8:decode(soundNames[soundfraction.v + 1])))
                        cfg['notf'].notf.fraction = soundfraction.v
                        saveIni('notf')
                        if cfg['notf'].notf.fraction == 0 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/fraction.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.fraction == 1 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/iphone.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.fraction == 2 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/vk.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.fraction == 3 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/notification.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.fraction == 4 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/icq.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.fraction == 5 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/facebook.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.fraction == 6 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/sos.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.fraction == 7 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/mysound.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        end
                    end

                    if imgui.Combo(u8 '/gov', soundgov, soundNames) then
                        msg(("�� ������� ����: {B2AAE6}%s"):format(u8:decode(soundNames[soundgov.v + 1])))
                        cfg['notf'].notf.gov = soundgov.v
                        saveIni('notf')
                        if cfg['notf'].notf.gov == 0 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/gov.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.gov == 1 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/iphone.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.gov == 2 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/vk.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.gov == 3 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/notification.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.gov == 4 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/icq.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.gov == 5 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/facebook.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.gov == 6 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/sos.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.gov == 7 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/mysound.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        end
                    end

                    if imgui.Combo(u8 '�������', soundnews, soundNames) then
                        msg(("�� ������� ����: {B2AAE6}%s"):format(u8:decode(soundNames[soundnews.v + 1])))
                        cfg['notf'].notf.news = soundnews.v
                        saveIni('notf')
                        if cfg['notf'].notf.news == 0 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/news.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.news == 1 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/iphone.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.news == 2 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/vk.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.news == 3 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/notification.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.news == 4 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/icq.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.news == 5 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/facebook.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.news == 6 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/sos.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.news == 7 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/mysound.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        end
                    end

                    if imgui.Combo(u8 '�����', soundplayers, soundNames) then
                        msg(("�� ������� ����: {B2AAE6}%s"):format(u8:decode(soundNames[soundplayers.v + 1])))
                        cfg['notf'].notf.players = soundplayers.v
                        saveIni('notf')
                        if cfg['notf'].notf.players == 0 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/player.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.players == 1 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/iphone.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.players == 2 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/vk.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.players == 3 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/notification.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.players == 4 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/icq.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.players == 5 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/facebook.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.players == 6 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/sos.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.players == 7 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/mysound.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        end
                    end

                    if imgui.Combo(u8 'SMS', soundsms, soundNames) then
                        msg(("�� ������� ����: {B2AAE6}%s"):format(u8:decode(soundNames[soundsms.v + 1])))
                        cfg['notf'].notf.sms = soundsms.v
                        saveIni('notf')
                        if cfg['notf'].notf.sms == 0 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/sms.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.sms == 1 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/iphone.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.sms == 2 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/vk.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.sms == 3 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/notification.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.sms == 4 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/icq.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.sms == 5 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/facebook.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.sms == 6 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/sos.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        elseif cfg['notf'].notf.sms == 7 then
                            notf = loadAudioStream("moonloader/ServerMessageNotf/notf/mysound.mp3")
                            setAudioStreamState(notf, 1)
                            setAudioStreamVolume(notf, cfg['notf'].settings.volume)
                        end
                    end

                    
                    imgui.SetCursorPosY(210)
                    imgui.CenterTextColoredRGB('{606060} DoubleClick for open folder')
                    if imgui.IsItemHovered() and imgui.IsMouseDoubleClicked(0) then os.execute('explorer '..mainPath) end

                    imgui.SetCursorPosX((imgui.GetWindowWidth() / 2 - imgui.CalcTextSize(u8'���������').x / 2))
                    imgui.Link("https://vk.com/vl4sov", u8"���������")
                    imgui.SetCursorPosX((imgui.GetWindowWidth() / 2 - imgui.CalcTextSize(u8'BlastHack').x / 2))
                    imgui.Link("https://www.blast.hk/members/155585", u8"BlastHack")

                imgui.PopItemWidth()

            imgui.EndChild()

            imgui.SetCursorPosX((imgui.GetWindowWidth() / 2 - imgui.CalcTextSize(u8'by vl4sov').x / 2))
            imgui.TextDisabled('by vl4sov')
            if imgui.IsItemClicked() then
                local bip = ('�%s�'):format(VowelLet[math.random(1, #VowelLet)])
                msg(bip)
            end

            imgui.SetCursorPosY(290)
            imgui.SetCursorPosX(60)
            if cfg['notf'].style.style then
                imgui.Text(faicons.ICON_MOON_O..u8' Ҹ���� ����')
                if imgui.IsItemClicked() then
                    cfg['notf'].style.style = false
                    msg('�������� ����� �������� �� �������')
                    saveIni('notf')
                end
            else
                imgui.Text(faicons.ICON_SUN_O..u8' ������� ����')
                if imgui.IsItemClicked() then
                    cfg['notf'].style.style = true
                    msg('�������� ����� �������� �� �����')
                    saveIni('notf')
                end
            end

        imgui.End()
    end
end

function imgui.Link(link, text)
    text = text or link
    local tSize = imgui.CalcTextSize(text)
    local p = imgui.GetCursorScreenPos()
    local DL = imgui.GetWindowDrawList()
    local col = { 0xFFFF7700, 0xFFFF9900 }
    if imgui.InvisibleButton("##" .. link, tSize) then os.execute("explorer " .. link) end
    local color = imgui.IsItemHovered() and col[1] or col[2]
    DL:AddText(p, color, text)
    DL:AddLine(imgui.ImVec2(p.x, p.y + tSize.y), imgui.ImVec2(p.x + tSize.x, p.y + tSize.y), color)
end

function imgui.ToggleButton(str_id, bool)
    local rBool = false

    if LastActiveTime == nil then
        LastActiveTime = {}
    end
    if LastActive == nil then
        LastActive = {}
    end

    local function ImSaturate(f)
        return f < 0.0 and 0.0 or (f > 1.0 and 1.0 or f)
    end
    
    local p = imgui.GetCursorScreenPos()
    local draw_list = imgui.GetWindowDrawList()

    local height = imgui.GetTextLineHeightWithSpacing()
    local width = height * 1.70
    local radius = height * 0.50
    local ANIM_SPEED = 0.15
    local butPos = imgui.GetCursorPos()

    if imgui.InvisibleButton(str_id, imgui.ImVec2(width, height)) then
        bool.v = not bool.v
        rBool = true
        LastActiveTime[tostring(str_id)] = os.clock()
        LastActive[tostring(str_id)] = true
    end

    imgui.SetCursorPos(imgui.ImVec2(butPos.x + width + 8, butPos.y + 1))
    imgui.Text( str_id:gsub('##.+', '') )

    local t = bool.v and 1.0 or 0.0

    if LastActive[tostring(str_id)] then
        local time = os.clock() - LastActiveTime[tostring(str_id)]
        if time <= ANIM_SPEED then
            local t_anim = ImSaturate(time / ANIM_SPEED)
            t = bool.v and t_anim or 1.0 - t_anim
        else
            LastActive[tostring(str_id)] = false
        end
    end
    
    local col_static = 0xFF202020
    local col = bool.v and imgui.ColorConvertFloat4ToU32(imgui.ImVec4(1.00, 0.28, 0.28, 1.00)) or 0xFF606060

    draw_list:AddRectFilled(imgui.ImVec2(p.x, p.y + (height / 6)), imgui.ImVec2(p.x + width - 1.0, p.y + (height - (height / 6))), col, 5.0)
    draw_list:AddCircleFilled(imgui.ImVec2(p.x + radius + t * (width - radius * 2.0), p.y + radius), radius - 0.75, col_static)
    draw_list:AddCircle(imgui.ImVec2(p.x + radius + t * (width - radius * 2.0), p.y + radius), radius - 0.75, col, 32, 2)

    return rBool
end

function imgui.CustomSlider(str_id, min, max, width, int) -- by aurora
    local p = imgui.GetCursorScreenPos()
    local draw_list = imgui.GetWindowDrawList()
    local pos = imgui.GetWindowPos()
    local posx,posy = getCursorPos()
    local n = max - min
    if int.v == 0 then
        int.v = min
    end
    local col_bg_active = imgui.GetColorU32(imgui.GetStyle().Colors[imgui.Col.ButtonActive])
    local col_bg_notactive = imgui.GetColorU32(imgui.GetStyle().Colors[imgui.Col.ModalWindowDarkening])
    draw_list:AddRectFilled(imgui.ImVec2(p.x + 7, p.y + 12), imgui.ImVec2(p.x + (width/n)*(int.v-min), p.y + 12), col_bg_active, 5.0)
    draw_list:AddRectFilled(imgui.ImVec2(p.x + (width/n)*(int.v-min), p.y + 12), imgui.ImVec2(p.x + width, p.y + 12), col_bg_notactive, 5.0)
    for i = 0, n do
        if posx > (p.x + i*width/(max+1) ) and posx < (p.x + (i+1)*width/(max+1)) and posy > p.y + 2 and posy < p.y + 22 and imgui.IsMouseDown(0) then
            int.v = i + min
            draw_list:AddCircleFilled(imgui.ImVec2(p.x + (width/n)*(int.v-min) + 4,  p.y + 7*2 - 2), 7+2, col_bg_active)
        end
    end
    imgui.SetCursorPos(imgui.ImVec2(p.x + width + 6 - pos.x, p.y - 8 - pos.y))
    imgui.Text(tostring(int.v))
    draw_list:AddCircleFilled(imgui.ImVec2(p.x + (width/n)*(int.v-min) + 4,  p.y + 7*2 - 2), 7, col_bg_active)
    imgui.NewLine()
    return int
end

function explode_argb(argb)
    local a = bit.band(bit.rshift(argb, 24), 0xFF)
    local r = bit.band(bit.rshift(argb, 16), 0xFF)
    local g = bit.band(bit.rshift(argb, 8), 0xFF)
    local b = bit.band(argb, 0xFF)
    return a, r, g, b
end

function imgui.CenterTextColoredRGB(text)
    local width = imgui.GetWindowWidth()
    local style = imgui.GetStyle()
    local colors = style.Colors
    local ImVec4 = imgui.ImVec4

    local explode_argb = function(argb)
        local a = bit.band(bit.rshift(argb, 24), 0xFF)
        local r = bit.band(bit.rshift(argb, 16), 0xFF)
        local g = bit.band(bit.rshift(argb, 8), 0xFF)
        local b = bit.band(argb, 0xFF)
        return a, r, g, b
    end

    local getcolor = function(color)
        if color:sub(1, 6):upper() == 'SSSSSS' then
            local r, g, b = colors[1].x, colors[1].y, colors[1].z
            local a = tonumber(color:sub(7, 8), 16) or colors[1].w * 255
            return ImVec4(r, g, b, a / 255)
        end
        local color = type(color) == 'string' and tonumber(color, 16) or color
        if type(color) ~= 'number' then return end
        local r, g, b, a = explode_argb(color)
        return imgui.ImColor(r, g, b, a):GetVec4()
    end

    local render_text = function(text_)
        for w in text_:gmatch('[^\r\n]+') do
            local textsize = w:gsub('{.-}', '')
            local text_width = imgui.CalcTextSize(u8(textsize))
            imgui.SetCursorPosX( width / 2 - text_width .x / 2 )
            local text, colors_, m = {}, {}, 1
            w = w:gsub('{(......)}', '{%1FF}')
            while w:find('{........}') do
                local n, k = w:find('{........}')
                local color = getcolor(w:sub(n + 1, k - 1))
                if color then
                    text[#text], text[#text + 1] = w:sub(m, n - 1), w:sub(k + 1, #w)
                    colors_[#colors_ + 1] = color
                    m = n
                end
                w = w:sub(1, n - 1) .. w:sub(k + 1, #w)
            end
            if text[0] then
                for i = 0, #text do
                    imgui.TextColored(colors_[i] or colors[1], u8(text[i]))
                    imgui.SameLine(nil, 0)
                end
                imgui.NewLine()
            else
                imgui.Text(u8(w))
            end
        end
    end
    render_text(text)
end

function sampev.onServerMessage(color, text)
    myid = select(2, sampGetPlayerIdByCharHandle(PLAYER_PED))
    mynick = sampGetPlayerNickname(myid)

    if cfg['notf'].settings.notfmessage and not text:match(mynick) then
        if (color == 33357768 or color == -1920073729) and cfg['notf'].settings.notffraction then

            if cfg['notf'].notf.fraction == 0 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/fraction.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.fraction == 1 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/iphone.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.fraction == 2 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/vk.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.fraction == 3 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/notification.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.fraction == 4 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/icq.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.fraction == 5 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/facebook.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.fraction == 6 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/sos.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.fraction == 7 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/mysound.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            end

        elseif color == 926416127 and text:match('�������') and cfg['notf'].settings.notfgov then

            if cfg['notf'].notf.gov == 0 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/gov.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.gov == 1 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/iphone.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.gov == 2 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/vk.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.gov == 3 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/notification.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.gov == 4 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/icq.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.gov == 5 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/facebook.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.gov == 6 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/sos.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.gov == 7 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/mysound.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            end

        elseif color == 14221567 and text:match('����������') and cfg['notf'].settings.notfnews then

            if cfg['notf'].notf.news == 0 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/news.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.news == 1 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/iphone.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.news == 2 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/vk.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.news == 3 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/notification.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.news == 4 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/icq.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.news == 5 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/facebook.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.news == 6 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/sos.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.news == 7 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/mysound.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            end

        elseif (color == -646512470 and text:match('����� ��')) or  color == -10270721 and cfg['notf'].settings.notfadmin then

            if cfg['notf'].notf.admins == 0 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/admin.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.admins == 1 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/iphone.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.admins == 2 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/vk.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.admins == 3 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/notification.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.admins == 4 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/icq.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.admins == 5 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/facebook.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.admins == 6 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/sos.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.admins == 7 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/mysound.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            end

        elseif color == -65366 and text:match('SMS%: .+. �����������%: .+') and cfg['notf'].settings.notfsms then

            if cfg['notf'].notf.sms == 0 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/sms.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.sms == 1 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/iphone.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.sms == 2 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/vk.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.sms == 3 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/notification.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.sms == 4 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/icq.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.sms == 5 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/facebook.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.sms == 6 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/sos.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.sms == 7 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/mysound.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            end

        elseif text:match(cfg['notf'].settings.familyname..':') and cfg['notf'].settings.notffamily then

            if cfg['notf'].notf.family == 0 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/family.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.family == 1 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/iphone.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.family == 2 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/vk.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.family == 3 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/notification.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.family == 4 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/icq.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.family == 5 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/facebook.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.family == 6 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/sos.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.family == 7 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/mysound.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            end

        elseif (text:match('- .+%[%d+%]%:') or text:match('- .+ %[%d+%]%:') or text:match('- (%w+_%w+):')) and cfg['notf'].settings.notfplayers then

            if cfg['notf'].notf.players == 0 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/player.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.players == 1 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/iphone.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.players == 2 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/vk.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.players == 3 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/notification.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.players == 4 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/icq.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.players == 5 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/facebook.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.players == 6 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/sos.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            elseif cfg['notf'].notf.players == 7 then
                notf = loadAudioStream("moonloader/ServerMessageNotf/notf/mysound.mp3")
                setAudioStreamState(notf, 1)
                setAudioStreamVolume(notf, cfg['notf'].settings.volume)
            end
        end
    end
end