script_name('onServerMessage Notf')
require("lib.moonloader")

sampev = require("lib.samp.events")

function main()
    if not isSampLoaded() and not isSampfuncsLoaded() and not sampIsLocalPlayerSpawned() then return end 
    while not isSampAvailable() do wait(0) end

    print('servermessage notf is loaded')

    while true do
        wait(0)

        -- �������

    end
end

function sampev.onServerMessage(color, text)
    notf = loadAudioStream("moonloader/config/notf.mp3")

    setAudioStreamState(notf, 1)
    setAudioStreamVolume(notf, 100)
end